package com.example.companion

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.Network
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Draws the companion over other apps, hosts the chat panel, and reacts to problems
 * (battery, network, storage, and error screens reported by [ProblemWatcherService]).
 */
class FloatingService : Service() {

    companion object {
        @Volatile
        var instance: FloatingService? = null
        const val ACTION_STOP = "com.example.companion.STOP"
        private const val CHANNEL = "companion"
        private const val NOTIF_ID = 1
        private const val ALERT_COOLDOWN_MS = 120_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var character: Character

    private lateinit var bubbleView: FrameLayout
    private lateinit var avatarText: TextView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var bubbleAdded = false
    private var bobAnim: ObjectAnimator? = null

    private var speechView: TextView? = null
    private var speechLp: WindowManager.LayoutParams? = null
    private val hideSpeech = Runnable { removeSpeech() }

    private var panel: LinearLayout? = null
    private var messageList: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null

    private val history = mutableListOf<Pair<String, String>>()
    private var pending: Problem? = null
    private val lastFired = HashMap<String, Long>()

    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private val netLost = Runnable {
        onProblem(Problem(ProblemKind.NO_INTERNET, "The phone lost its connection."))
    }
    private val storageCheck = object : Runnable {
        override fun run() {
            checkStorage()
            main.postDelayed(this, 10 * 60_000L)
        }
    }

    private val bubbleSize get() = dp(60)
    private val screenW get() = resources.displayMetrics.widthPixels
    private val screenH get() = resources.displayMetrics.heightPixels

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        character = Characters.byId(Prefs.characterId(this))
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        buildBubble()
        registerWatchers()
        main.postDelayed({ showSpeech(character.greeting) }, 600)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        netCallback?.let {
            runCatching { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        }
        batteryReceiver?.let { runCatching { unregisterReceiver(it) } }
        removeSpeech()
        panel?.let { safeRemove(it) }
        if (bubbleAdded) safeRemove(bubbleView)
        bobAnim?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground notification

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Companion", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("${character.name} is with you")
            .setContentText("Floating on your screen. Tap to open settings.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- floating bubble

    private fun buildBubble() {
        avatarText = TextView(this).apply {
            text = character.emoji
            textSize = 30f
            gravity = Gravity.CENTER
        }
        bubbleView = FrameLayout(this).apply {
            background = ovalBg(character.color)
            addView(avatarText, FrameLayout.LayoutParams(bubbleSize, bubbleSize))
        }
        bubbleLp = WindowManager.LayoutParams(
            bubbleSize, bubbleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - bubbleSize - dp(4)
            y = screenH / 3
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        bubbleView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = bubbleLp.x; startY = bubbleLp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        bubbleLp.x = (startX + dx).toInt()
                        bubbleLp.y = (startY + dy).toInt()
                        wm.updateViewLayout(bubbleView, bubbleLp)
                        positionSpeech()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) snapToEdge() else onBubbleTap()
                    true
                }
                else -> false
            }
        }
        wm.addView(bubbleView, bubbleLp)
        bubbleAdded = true
        startBobbing()
    }

    private fun startBobbing() {
        bobAnim?.cancel()
        bobAnim = ObjectAnimator.ofFloat(avatarText, "translationY", 0f, -dp(4).toFloat()).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            start()
        }
    }

    private fun snapToEdge() {
        val target = if (bubbleLp.x + bubbleSize / 2 < screenW / 2) dp(4) else screenW - bubbleSize - dp(4)
        bubbleLp.y = bubbleLp.y.coerceIn(dp(24), screenH - bubbleSize - dp(64))
        ValueAnimator.ofInt(bubbleLp.x, target).apply {
            duration = 180
            addUpdateListener {
                bubbleLp.x = it.animatedValue as Int
                if (bubbleAdded) wm.updateViewLayout(bubbleView, bubbleLp)
                positionSpeech()
            }
            start()
        }
    }

    private fun wiggle() {
        ObjectAnimator.ofFloat(avatarText, "rotation", 0f, -18f, 18f, -12f, 12f, 0f).setDuration(700).start()
    }

    private fun onBubbleTap() {
        val p = pending
        pending = null
        openPanel(p)
    }

    // ---------------------------------------------------------------- speech bubble

    private fun showSpeech(text: String) {
        if (panel != null || !bubbleAdded) return
        removeSpeech()
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(0xFF1B1B1F.toInt())
            maxWidth = dp(230)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundBg(0xFFFFFFFF.toInt(), 16f, character.color, 2)
            setOnClickListener { onBubbleTap() }
        }
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(dp(230), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        speechView = tv
        speechLp = lp
        positionSpeech()
        wm.addView(tv, lp)
        main.removeCallbacks(hideSpeech)
        main.postDelayed(hideSpeech, 9_000)
    }

    private fun positionSpeech() {
        val sv = speechView ?: return
        val lp = speechLp ?: return
        val w = sv.measuredWidth
        val h = sv.measuredHeight
        val centerX = bubbleLp.x + bubbleSize / 2
        var x = if (centerX > screenW / 2) bubbleLp.x + bubbleSize - w else bubbleLp.x
        x = x.coerceIn(dp(8), (screenW - w - dp(8)).coerceAtLeast(dp(8)))
        var y = bubbleLp.y - h - dp(8)
        if (y < dp(24)) y = bubbleLp.y + bubbleSize + dp(8)
        lp.x = x
        lp.y = y
        if (sv.isAttachedToWindow) runCatching { wm.updateViewLayout(sv, lp) }
    }

    private fun removeSpeech() {
        main.removeCallbacks(hideSpeech)
        speechView?.let { safeRemove(it) }
        speechView = null
        speechLp = null
    }

    // ---------------------------------------------------------------- chat panel

    private fun openPanel(problem: Problem? = null) {
        if (panel == null) {
            removeSpeech()
            bubbleView.visibility = View.GONE
            buildPanel()
            if (history.isEmpty()) addMessage(character.greeting, fromUser = false)
        }
        if (problem != null) askAboutProblem(problem)
    }

    private fun buildPanel() {
        val root = object : LinearLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    closePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(0xF2161A2B.toInt(), 24f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = character.emoji; textSize = 26f })
        header.addView(TextView(this).apply {
            text = "  ${character.name}"
            setTextColor(Color.WHITE)
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "🗑"
            textSize = 18f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { clearChat() }
        })
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { closePanel() }
        })
        root.addView(header)

        // messages
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(list) }
        messageList = list
        scroll = sv
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(280)).apply {
            topMargin = dp(8)
        })

        // input row
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(this).apply {
            hint = "Talk to ${character.name}…"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            background = roundBg(0x26FFFFFF, 20f)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendFromInput(); true } else false
            }
        }
        input = et
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "➤"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = ovalBg(character.color)
            setOnClickListener { sendFromInput() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val lp = WindowManager.LayoutParams(
            screenW - dp(24), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }
        wm.addView(root, lp)
        panel = root

        // replay existing conversation after a reopen
        history.forEach { (role, text) -> addMessage(text, fromUser = role == "user") }
    }

    private fun closePanel() {
        panel?.let { safeRemove(it) }
        panel = null
        messageList = null
        scroll = null
        input = null
        if (bubbleAdded) bubbleView.visibility = View.VISIBLE
    }

    private fun clearChat() {
        history.clear()
        messageList?.removeAllViews()
        addMessage(character.greeting, fromUser = false)
    }

    private fun addMessage(text: String, fromUser: Boolean): TextView? {
        val list = messageList ?: return null
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14.5f
            setTextColor(Color.WHITE)
            maxWidth = (screenW * 0.72f).toInt()
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundBg(if (fromUser) character.color else 0x33FFFFFF, 16f)
        }
        list.addView(tv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(6)
            gravity = if (fromUser) Gravity.END else Gravity.START
        })
        scrollDown()
        return tv
    }

    private fun scrollDown() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendFromInput() {
        val et = input ?: return
        val text = et.text.toString().trim()
        if (text.isEmpty()) return
        et.setText("")
        ask(prompt = text, display = text, problem = null)
    }

    // ---------------------------------------------------------------- AI conversation

    private fun systemPrompt(): String = """
        ${character.persona}

        You are a small floating companion living on the user's Android phone screen. Match the user's language (English, Hindi or Hinglish).
        Stay fully in character in tone, but be genuinely useful. Keep replies under 70 words unless asked for more.
        When the user has a problem, give short numbered steps with exact Android Settings paths and mention that menu names vary by phone brand.
        You cannot tap or change anything on the phone yourself; you can only advise. Never ask for passwords, OTPs, PINs or card details.
    """.trimIndent()

    private fun askAboutProblem(p: Problem) {
        val app = p.pkg?.let { " It happened in the app: ${appLabel(it)}." } ?: ""
        val detail = if (p.detail.isNotBlank()) " Details: ${p.detail}" else ""
        ask(
            prompt = "My phone has a problem: ${p.kind.title}.$detail$app Please help me fix it, step by step.",
            display = "🆘 ${p.kind.title}",
            problem = p
        )
    }

    private fun ask(prompt: String, display: String, problem: Problem?) {
        addMessage(display, fromUser = true)
        history.add("user" to prompt)
        val typing = addMessage("${character.emoji} …", fromUser = false)
        val key = Prefs.apiKey(this)
        if (key.isBlank()) {
            val reply = offlineReply(problem)
            typing?.text = reply
            history.add("assistant" to reply)
            scrollDown()
            return
        }
        scope.launch {
            val result = AiClient.chat(key, systemPrompt(), history.takeLast(12))
            val reply = result.getOrElse {
                "Couldn't reach my brain (${it.message}).\n" +
                    (problem?.kind?.tip ?: "Check your internet connection and API key in the app.")
            }
            typing?.text = reply
            if (result.isSuccess) history.add("assistant" to reply)
            scrollDown()
        }
    }

    private fun offlineReply(problem: Problem?): String =
        if (problem != null) {
            "${character.opener}\n${problem.kind.tip}\n\n(Add your API key in the app so I can chat properly.)"
        } else {
            "${character.opener}\nI need an API key to chat. Open the app and paste it in. " +
                "Meanwhile I'll still warn you when something goes wrong!"
        }

    // ---------------------------------------------------------------- problem handling

    /** Entry point for all detectors. Safe to call from any thread. */
    fun onProblem(p: Problem) {
        main.post {
            val key = p.kind.name + (p.pkg ?: "")
            val now = SystemClock.elapsedRealtime()
            val last = lastFired[key]
            if (last != null && now - last < ALERT_COOLDOWN_MS) return@post
            lastFired[key] = now

            if (!bubbleAdded) return@post
            if (panel != null) {
                askAboutProblem(p)
                return@post
            }
            pending = p
            wiggle()
            val detail = if (p.detail.isNotBlank()) "\n${p.detail.take(90)}" else ""
            showSpeech("${character.opener}\n⚠️ ${p.kind.title}$detail\nTap me and I'll help!")
        }
    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun registerWatchers() {
        // Low battery
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                onProblem(Problem(ProblemKind.LOW_BATTERY, "Battery is at $level%."))
            }
        }
        val filter = IntentFilter(Intent.ACTION_BATTERY_LOW)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        batteryReceiver = receiver

        // Lost connection (debounced so Wi-Fi to mobile handovers don't trigger it)
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                main.postDelayed(netLost, 5_000)
            }

            override fun onAvailable(network: Network) {
                main.removeCallbacks(netLost)
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb) }.onSuccess { netCallback = cb }

        // Low storage
        main.postDelayed(storageCheck, 15_000)
    }

    private fun checkStorage() {
        val free = runCatching { StatFs(Environment.getDataDirectory().path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        if (free < 1_000_000_000L) {
            val gb = free / 1_000_000_000.0
            onProblem(Problem(ProblemKind.LOW_STORAGE, "Only %.1f GB free.".format(gb)))
        }
    }

    // ---------------------------------------------------------------- misc

    /** Called by the setup screen when the user picks a different character while the service runs. */
    fun refreshCharacter() {
        main.post {
            character = Characters.byId(Prefs.characterId(this))
            history.clear()
            pending = null
            if (panel != null) closePanel()
            if (bubbleAdded) {
                avatarText.text = character.emoji
                bubbleView.background = ovalBg(character.color)
                showSpeech(character.greeting)
            }
        }
    }

    private fun safeRemove(v: View) {
        runCatching { wm.removeView(v) }
    }
}
