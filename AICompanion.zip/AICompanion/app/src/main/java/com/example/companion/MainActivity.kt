package com.example.companion

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Setup screen: API key, character picker, permissions, start/stop. */
class MainActivity : Activity() {

    private lateinit var keyInput: EditText
    private lateinit var overlayStatus: TextView
    private lateinit var a11yStatus: TextView
    private val cards = LinkedHashMap<String, LinearLayout>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        refreshCards()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        col.addView(label("AI Companion", 28f, bold = true))
        col.addView(label("A floating friend that chats in character and jumps in when something goes wrong.", 14f, topDp = 4, color = 0xFF5F6368.toInt()))

        col.addView(section("1. Claude API key"))
        keyInput = EditText(this).apply {
            hint = "sk-ant-…"
            setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        col.addView(keyInput)
        col.addView(label("Create a key at console.anthropic.com. It is stored only on this phone and sent only to Anthropic's API when you chat.", 12f, color = 0xFF5F6368.toInt()))

        col.addView(section("2. Choose your companion"))
        Characters.all.forEach { c ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener {
                    Prefs.setCharacterId(this@MainActivity, c.id)
                    refreshCards()
                    FloatingService.instance?.refreshCharacter()
                }
            }
            card.addView(TextView(this).apply { text = c.emoji; textSize = 30f })
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, 0, 0)
            }
            texts.addView(label(c.name, 16f, bold = true))
            texts.addView(label(c.tagline, 13f, color = 0xFF5F6368.toInt()))
            card.addView(texts)
            cards[c.id] = card
            col.addView(card, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) })
        }

        col.addView(section("3. Permissions"))
        overlayStatus = label("", 14f)
        col.addView(overlayStatus)
        col.addView(button("Allow display over other apps") { openOverlaySettings() })
        a11yStatus = label("", 14f, topDp = 12)
        col.addView(a11yStatus)
        col.addView(button("Enable problem detection (optional)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(label(
            "Problem detection lets your companion notice crash and error screens. Battery, network and storage warnings work without it.",
            12f, color = 0xFF5F6368.toInt()
        ))

        col.addView(section("4. Go!"))
        col.addView(button("Start companion") { start() })
        col.addView(button("Stop companion") {
            stopService(Intent(this, FloatingService::class.java))
            toast("Companion stopped")
        })

        return ScrollView(this).apply {
            setBackgroundColor(0xFFF7F7FB.toInt())
            addView(col)
        }
    }

    private fun start() {
        Prefs.setApiKey(this, keyInput.text.toString())
        if (!Settings.canDrawOverlays(this)) {
            toast("Please allow 'Display over other apps' first")
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        toast("${Characters.byId(Prefs.characterId(this)).name} is now floating on your screen")
        moveTaskToBack(true)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        overlayStatus.text = if (overlay) "✅ Display over other apps: allowed" else "⬜ Display over other apps: not allowed yet"
        a11yStatus.text = if (isAccessibilityOn()) "✅ Problem detection: on" else "⬜ Problem detection: off (optional)"
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(this, ProblemWatcherService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), ignoreCase = true) || it.equals(cn.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun refreshCards() {
        val selected = Prefs.characterId(this)
        cards.forEach { (id, card) ->
            val c = Characters.byId(id)
            card.background = if (id == selected) {
                roundBg(0xFFFFFFFF.toInt(), 16f, c.color, 3)
            } else {
                roundBg(0xFFFFFFFF.toInt(), 16f, 0xFFE0E0E6.toInt(), 1)
            }
        }
    }

    // ---- small UI helpers

    private fun section(text: String) = label(text, 18f, bold = true, topDp = 24)

    private fun label(text: String, size: Float, bold: Boolean = false, topDp: Int = 0, color: Int = Color.BLACK) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(topDp), 0, dp(4))
        }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
